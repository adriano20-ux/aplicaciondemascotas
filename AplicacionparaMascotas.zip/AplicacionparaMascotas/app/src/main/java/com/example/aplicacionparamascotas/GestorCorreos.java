package com.example.aplicacionparamascotas;
import android.content.Context;
import android.content.SharedPreferences;

import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class GestorCorreos {
    private static final String CORREO_REMITENTE = "vega.adrian3005@gmail.com";
    private static final String PASSWORD_APP = "lhdf lbco hsaj fjia";

    public static void enviarCorreo(Context context, String correoDestino, String asunto, String mensajeTexto) {
        // Ejecutamos en segundo plano para no congelar la pantalla de la app
        SharedPreferences prefs = context.getSharedPreferences("AjustesApp", Context.MODE_PRIVATE);
        boolean correoActivo = prefs.getBoolean("correo_activo", true);

        // Si el usuario apagó las notificaciones en ajustes, cancelamos el envío
        if (!correoActivo) {
            return;
        }
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(CORREO_REMITENTE, PASSWORD_APP);
                }
            });

            try {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(CORREO_REMITENTE));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoDestino));
                message.setSubject(asunto);
                message.setText(mensajeTexto);

                Transport.send(message);
                System.out.println("¡Correo enviado con éxito!");

            } catch (MessagingException e) {
                e.printStackTrace();
            }
        });
    }
}
