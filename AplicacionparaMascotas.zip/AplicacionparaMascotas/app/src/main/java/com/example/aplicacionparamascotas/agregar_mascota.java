package com.example.aplicacionparamascotas;

import android.app.DatePickerDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;


import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.annotation.NonNull;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import com.google.firebase.firestore.DocumentReference;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class agregar_mascota extends AppCompatActivity {

    private ImageView ivVolverRegistro, ivMascotaFoto;
    private TextInputEditText etMascotaNombre, etMascotaFecha, etMascotaPeso;
    private RadioGroup rgEspecie;
    private RadioButton rbPerro, rbGato;
    private Spinner spinnerRaza;
    private Button btnGuardarMascota;


    // Declaración de variables de Firebase
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;


    private Uri imageUri = null; // Guardará la ruta de la foto elegida temporalmente
    private ActivityResultLauncher<String> galleryLauncher;

    // Listas de razas
    private String[] razasPerro = {"Chihuahua", "Labrador", "Bulldog", "Pug", "Golden Retriever", "Mestizo", "Otro"};
    private String[] razasGato = {"Persa", "Siamés", "Angora", "Maine Coon", "Mestizo", "Otro"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregar_mascota);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        ivVolverRegistro = findViewById(R.id.ivVolverRegistro);
        ivMascotaFoto = findViewById(R.id.ivMascotaFoto);
        etMascotaNombre = findViewById(R.id.etMascotaNombre);
        etMascotaFecha = findViewById(R.id.etMascotaFecha);
        etMascotaPeso = findViewById(R.id.etMascotaPeso);
        rgEspecie = findViewById(R.id.rgEspecie);
        rbPerro = findViewById(R.id.rbPerro);
        rbGato = findViewById(R.id.rbGato);
        spinnerRaza = findViewById(R.id.spinnerRaza);
        btnGuardarMascota = findViewById(R.id.btnGuardarMascota);

        ivVolverRegistro.setOnClickListener(v -> finish());

        // Capturador de la galería
        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        imageUri = uri;
                        ivMascotaFoto.setImageTintList(null);
                        ivMascotaFoto.setImageURI(uri);
                        ivMascotaFoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    }
                }
        );

        ivMascotaFoto.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        cargarRazas(razasPerro);

        rgEspecie.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbPerro) {
                cargarRazas(razasPerro);
            } else if (checkedId == R.id.rbGato) {
                cargarRazas(razasGato);
            }
        });

        etMascotaFecha.setOnClickListener(v -> mostrarCalendario());

        btnGuardarMascota.setOnClickListener(v -> procesarFotoYGuardar());
    }

    private void cargarRazas(String[] listaRazas) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaRazas);
        spinnerRaza.setAdapter(adapter);
    }

    private void mostrarCalendario() {
        Calendar calendario = Calendar.getInstance();
        int anio = calendario.get(Calendar.YEAR);
        int mes = calendario.get(Calendar.MONTH);
        int dia = calendario.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            String fechaSeleccionada = dayOfMonth + "/" + (month + 1) + "/" + year;
            etMascotaFecha.setText(fechaSeleccionada);
        }, anio, mes, dia);
        dpd.show();
    }

    // Convertir la imagen a texto (Base64) antes de guardar
    private void procesarFotoYGuardar() {
        String nombre = etMascotaNombre.getText().toString().trim();
        String fechaNacimiento = etMascotaFecha.getText().toString().trim();
        String peso = etMascotaPeso.getText().toString().trim();

        if (nombre.isEmpty()) { etMascotaNombre.setError("Ingresa el nombre"); return; }
        if (fechaNacimiento.isEmpty()) { etMascotaFecha.setError("Selecciona una fecha"); return; }
        if (peso.isEmpty()) { etMascotaPeso.setError("Ingresa el peso"); return; }

        Toast.makeText(this, "Guardando información...", Toast.LENGTH_SHORT).show();

        String fotoBase64 = ""; // Si no hay foto, se guarda vacío
        if (imageUri != null) {
            try {
                // Comprimir la imagen para que Firestore la acepte sin problemas
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, baos); // 40% de calidad para ahorrar espacio
                byte[] imageBytes = baos.toByteArray();
                fotoBase64 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_SHORT).show();
            }
        }

        guardarMascota(nombre, fechaNacimiento, peso, fotoBase64);
    }

    private void guardarMascota(String nombre, String fechaNacimiento, String peso, String fotoBase64) {
        String especie = rbPerro.isChecked() ? "Perro" : "Gato";
        String raza = spinnerRaza.getSelectedItem().toString();
        String userId = mAuth.getCurrentUser().getUid();

        Map<String, Object> mascota = new HashMap<>();
        mascota.put("nombre", nombre);
        mascota.put("especie", especie);
        mascota.put("raza", raza);
        mascota.put("fechaNacimiento", fechaNacimiento);
        mascota.put("peso", peso);
        mascota.put("fotoBase64", fotoBase64); // Guardamos la imagen como texto

        db.collection("Usuarios").document(userId).collection("MisMascotas")
                .add(mascota)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(agregar_mascota.this, "¡Mascota agregada con éxito!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(agregar_mascota.this, "Error al guardar", Toast.LENGTH_LONG).show());
    }
}