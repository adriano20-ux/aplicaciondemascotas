package com.example.aplicacionparamascotas;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class editar_mascota extends AppCompatActivity {
    private Button btnEliminarMascota;

    private ImageView ivVolverEditar, ivEditarFoto;
    private TextInputEditText etEditarNombre, etEditarPeso;
    private Button btnActualizarMascota;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private String mascotaId;
    private String userId;
    private Uri imageUri = null;
    private ActivityResultLauncher<String> galleryLauncher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar_mascota);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        userId = mAuth.getCurrentUser().getUid();

        btnEliminarMascota = findViewById(R.id.btnEliminarMascota);
        ivVolverEditar = findViewById(R.id.ivVolverEditar);
        ivEditarFoto = findViewById(R.id.ivEditarFoto);
        etEditarNombre = findViewById(R.id.etEditarNombre);
        etEditarPeso = findViewById(R.id.etEditarPeso);
        btnActualizarMascota = findViewById(R.id.btnActualizarMascota);


        ivVolverEditar.setOnClickListener(v -> finish());

        // Recibir ID de la mascota
        mascotaId = getIntent().getStringExtra("MASCOTA_ID");

        if (mascotaId != null) {
            cargarDatosMascota();
        } else {
            Toast.makeText(this, "Error al cargar el perfil", Toast.LENGTH_SHORT).show();
            finish();
        }
        btnEliminarMascota.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Eliminar Mascota")
                    .setMessage("¿Estás seguro de que deseas eliminar este perfil? Esta acción no se puede deshacer.")
                    .setPositiveButton("Sí, eliminar", (dialog, which) -> {

                        // Usamos directamente la variable global 'mascotaId' que ya se cargó arriba
                        if (mascotaId != null && userId != null) {
                            db.collection("Usuarios")
                                    .document(userId)
                                    .collection("MisMascotas")
                                    .document(mascotaId)
                                    .delete()
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(this, "Mascota eliminada correctamente", Toast.LENGTH_SHORT).show();
                                        finish(); // Cierra la pantalla y regresa a la lista
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(this, "Error al borrar: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                    });
                        } else {
                            Toast.makeText(this, "Error: No se encontró el ID de la mascota", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });


        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        imageUri = uri;
                        ivEditarFoto.setImageTintList(null);
                        ivEditarFoto.setImageURI(uri);
                        ivEditarFoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    }
                }
        );

        // Al tocar la foto, abrimos la galería
        ivEditarFoto.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        btnActualizarMascota.setOnClickListener(v -> actualizarMascota());
    }


    private void cargarDatosMascota() {
        db.collection("Usuarios").document(userId).collection("MisMascotas").document(mascotaId)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot document) {
                        if (document.exists()) {
                            etEditarNombre.setText(document.getString("nombre"));
                            etEditarPeso.setText(document.getString("peso"));

                            // Si la mascota ya tiene una foto en Base64, la mostramos
                            String fotoBase64 = document.getString("fotoBase64");
                            if (fotoBase64 != null && !fotoBase64.isEmpty()) {
                                try {
                                    ivEditarFoto.setImageTintList(null);
                                    byte[] decodedString = Base64.decode(fotoBase64, Base64.DEFAULT);
                                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                    ivEditarFoto.setImageBitmap(decodedByte);
                                    ivEditarFoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                });
    }

    private void actualizarMascota() {
        String nuevoNombre = etEditarNombre.getText().toString().trim();
        String nuevoPeso = etEditarPeso.getText().toString().trim();

        if (nuevoNombre.isEmpty()) { etEditarNombre.setError("Requerido"); return; }
        if (nuevoPeso.isEmpty()) { etEditarPeso.setError("Requerido"); return; }

        Toast.makeText(this, "Actualizando...", Toast.LENGTH_SHORT).show();

        Map<String, Object> actualizaciones = new HashMap<>();
        actualizaciones.put("nombre", nuevoNombre);
        actualizaciones.put("peso", nuevoPeso);

        // Si el usuario eligió una nueva foto, la convertimos y la agregamos a la actualización
        if (imageUri != null) {
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, baos);
                byte[] imageBytes = baos.toByteArray();
                String fotoBase64 = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                actualizaciones.put("fotoBase64", fotoBase64); // Actualizamos la foto en Firebase
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        db.collection("Usuarios").document(userId).collection("MisMascotas").document(mascotaId)
                .update(actualizaciones)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(editar_mascota.this, "¡Perfil actualizado!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(editar_mascota.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
