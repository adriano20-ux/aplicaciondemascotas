package com.example.aplicacionparamascotas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.Calendar;

public class agenda extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agenda);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageView ivVolverAgenda = findViewById(R.id.ivVolverAgenda);
        ivVolverAgenda.setOnClickListener(v -> finish());
        Button btnGuardarAgenda = findViewById(R.id.btnGuardarAgenda);


        btnGuardarAgenda.setOnClickListener(v -> {
            // Para probar, configuramos la alarma 15 segundos en el futuro
            Calendar calendario = Calendar.getInstance();
            calendario.add(Calendar.SECOND, 15);

            // Preparamos la entrega para nuestro "Cartero"
            Intent intentReceiver = new Intent(agenda.this, RecordatorioReceiver.class);

            // FLAG_IMMUTABLE es obligatorio en Android modernos
            PendingIntent pendingIntent = PendingIntent.getBroadcast(agenda.this, 0, intentReceiver, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);


            // Activamos el Despertador de Android
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                try {
                    // Le decimos que sea una alarma EXACTA
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendario.getTimeInMillis(), pendingIntent);
                    Toast.makeText(this, "¡Notificación programada! Cierra la app y espera 15 segundos", Toast.LENGTH_LONG).show();
                } catch (SecurityException e) {
                    Toast.makeText(this, "Falta dar permiso de alarmas exactas", Toast.LENGTH_SHORT).show();
                }
            }
            String correoDestino = FirebaseAuth.getInstance().getCurrentUser().getEmail();

            GestorCorreos.enviarCorreo(
                    agenda.this,
                    correoDestino,
                    "Recordatorio de tu Mascota 🐾",
                    "Hola! Tienes una cita pendiente en tu agenda. ¡No te olvides!"
            );
            // Aviso final para el usuario
            android.widget.Toast.makeText(this, "Notificación programada y Correo enviado...", android.widget.Toast.LENGTH_LONG).show();
        });

    }
}