package com.example.aplicacionparamascotas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ajustes extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private TextView tvCorreoUsuario;
    private Spinner spinnerPeso;
    private Button btnCerrarSesion;
    private ImageView ivVolver;
    private SwitchCompat switchNotificaciones, switchRecordatorios;
    private View btnFaq;
    private View btnTerminos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ajustes);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mAuth = FirebaseAuth.getInstance();

        // Enlazar vistas
        tvCorreoUsuario = findViewById(R.id.tvCorreoUsuario);
        spinnerPeso = findViewById(R.id.spinnerPeso);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);
        ivVolver = findViewById(R.id.ivVolver);
        switchNotificaciones = findViewById(R.id.switchNotificaciones);
        switchRecordatorios = findViewById(R.id.switchRecordatorios);
        btnFaq = findViewById(R.id.btnFaq);
        btnTerminos = findViewById(R.id.btnTerminos);

        SharedPreferences prefsEmail = getSharedPreferences("AjustesApp", MODE_PRIVATE);
        boolean correoActivo = prefsEmail.getBoolean("correo_activo", true); // Por defecto encendido
        switchRecordatorios.setChecked(correoActivo);

        switchRecordatorios.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefsEmail.edit().putBoolean("correo_activo", isChecked).apply();
            Toast.makeText(this, "Correos " + (isChecked ? "Activados" : "Desactivados"), Toast.LENGTH_SHORT).show();
        });

        SharedPreferences prefs = getSharedPreferences("AjustesApp", MODE_PRIVATE);
        boolean activadas = prefs.getBoolean("notificaciones_activas", true); // Por defecto en true
        switchNotificaciones.setChecked(activadas);

        switchNotificaciones.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("notificaciones_activas", isChecked).apply();
            Toast.makeText(this, "Notificaciones " + (isChecked ? "Activadas" : "Desactivadas"), Toast.LENGTH_SHORT).show();
        });
        // Flecha para volver al Dashboard
        ivVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ajustes.this, faq.class);
                startActivity(intent);
            }
        });

        btnTerminos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ajustes.this, terminos.class);
                startActivity(intent);
            }
        });

        // Mostrar correo
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            tvCorreoUsuario.setText(currentUser.getEmail());
        }

        // Llenar Spinner
        String[] opcionesPeso = {"Kilogramos (kg)", "Libras (lb)"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, opcionesPeso);
        spinnerPeso.setAdapter(adapter);
        SharedPreferences prefsPeso = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        boolean usarLibras = prefsPeso.getBoolean("usarLibras", false); // Por defecto falso (Kg)

        // 1. Mostrar la opción guardada al entrar a Ajustes
        if (usarLibras) {
            spinnerPeso.setSelection(1); // Libras
        } else {
            spinnerPeso.setSelection(0); // Kg
        }

        // 2. Guardar en memoria cuando el usuario cambie la opción
        spinnerPeso.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                // Posición 1 es Libras, Posición 0 es Kg
                boolean selecciono_libras = (position == 1);
                prefs.edit().putBoolean("usarLibras", selecciono_libras).apply();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });

        // Cerrar Sesión
        btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Toast.makeText(ajustes.this, "Sesión cerrada", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(ajustes.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }
}