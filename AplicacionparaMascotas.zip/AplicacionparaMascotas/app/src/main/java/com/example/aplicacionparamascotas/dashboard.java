package com.example.aplicacionparamascotas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;

public class dashboard extends AppCompatActivity {
    private View btnAgenda;
    private View btnRazas;
    private String pesoOriginalMascota = null;
    private boolean configLibrasPintada = false;
    private String idMascotaPintada = null;
    private View btnMisMascotas;
    private ImageView ivOpcionesMascota, ivPerfilMascota;
    private ImageView ivConfigurar;
    private TextView tvSaludo;

    private TextView tvDashboardPeso;

    private LinearLayout layoutSinMascotas;
    private LinearLayout layoutConMascotas;
    private Button btnAgregarMascota;
    private TextView tvNombreMascota;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Enlazar vistas
        btnAgenda=findViewById(R.id.btnAgenda);
        tvDashboardPeso = findViewById(R.id.tvDashboardPeso);
        btnMisMascotas = findViewById(R.id.btnMisMascotas);
        ivPerfilMascota = findViewById(R.id.ivPerfilMascota);
        ivOpcionesMascota = findViewById(R.id.ivOpcionesMascota);
        ivConfigurar = findViewById(R.id.ivConfigurar);
        tvSaludo = findViewById(R.id.tvSaludo);
        layoutSinMascotas = findViewById(R.id.layoutSinMascotas);
        layoutConMascotas = findViewById(R.id.layoutConMascotas);
        btnAgregarMascota = findViewById(R.id.btnAgregarMascota);
        tvNombreMascota = findViewById(R.id.tvNombreMascota);

        // Saludo personalizado
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null && currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
            String primerNombre = currentUser.getDisplayName().split(" ")[0];
            tvSaludo.setText("¡Hola " + primerNombre + "!");
        } else {
            tvSaludo.setText("¡Hola!");
        }
        btnAgenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(dashboard.this,agenda.class);
                startActivity(intent);
            }
        });
        btnRazas = findViewById(R.id.btnRazas);

        btnRazas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Viajamos desde el dashboard hacia tu nueva pantalla "razas"
                Intent intent = new Intent(dashboard.this, razas.class);
                startActivity(intent);
            }
        });
        // Configurar botón de ajustes
        ivConfigurar.setOnClickListener(v -> {
            Intent intent = new Intent(dashboard.this, ajustes.class);
            startActivity(intent);
        });
        btnMisMascotas.setOnClickListener(v -> {
            Intent intent = new Intent(dashboard.this, mismascotas.class);
            startActivity(intent);
        });

        // Acción del botón Agregar Mascota
        btnAgregarMascota.setOnClickListener(v -> {
            Intent intent = new Intent(dashboard.this, agregar_mascota.class);
            startActivity(intent);
        });

        if (currentUser != null) {
            String userId = currentUser.getUid();

            // Ponemos a Firestore a "escuchar" la colección de MisMascotas de este usuario
            db.collection("Usuarios").document(userId).collection("MisMascotas")
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                            if (error != null) {
                                Toast.makeText(dashboard.this, "Error al cargar mascotas", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            if (value != null && !value.isEmpty()) {
                                // Ocultar mensaje de vacío y mostrar el panel de la mascota
                                layoutSinMascotas.setVisibility(View.GONE);
                                layoutConMascotas.setVisibility(View.VISIBLE);

                                DocumentSnapshot mascotaActual = null;
                                android.content.SharedPreferences prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
                                String mascotaActivaId = prefs.getString("mascotaActivaId", null);

                                if (mascotaActivaId != null) {
                                    for (DocumentSnapshot doc : value.getDocuments()) {
                                        if (doc.getId().equals(mascotaActivaId)) {
                                            mascotaActual = doc;
                                            break;
                                        }
                                    }
                                }

                                if (mascotaActual == null) {
                                    mascotaActual = value.getDocuments().get(0);
                                    // La guardamos en memoria para la próxima vez
                                    prefs.edit().putString("mascotaActivaId", mascotaActual.getId()).apply();
                                }
                                idMascotaPintada = mascotaActual.getId();

                                String nombre = mascotaActual.getString("nombre");
                                String raza = mascotaActual.getString("raza");
                                tvNombreMascota.setText(nombre + " (" + raza + ")");
                                String pesoTexto = mascotaActual.getString("peso");
                                pesoOriginalMascota = pesoTexto;

                                android.content.SharedPreferences prefsDashboard = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
                                boolean mostrarEnLibras = prefsDashboard.getBoolean("usarLibras", false);
                                configLibrasPintada = mostrarEnLibras;
                                if (pesoTexto != null && !pesoTexto.isEmpty()) {
                                    try {
                                        double pesoOriginalKg = Double.parseDouble(pesoTexto);

                                        if (mostrarEnLibras) {
                                            double pesoLb = pesoOriginalKg * 2.20462;
                                            tvDashboardPeso.setText(String.format("Peso: %.2f Lb", pesoLb));
                                        } else {
                                            tvDashboardPeso.setText("Peso: " + pesoTexto + " Kg");
                                        }
                                    } catch (Exception e) {
                                        tvDashboardPeso.setText("Peso: " + pesoTexto);
                                    }
                                } else {
                                    tvDashboardPeso.setText("Peso: No registrado");
                                }

                                String fotoBase64 = mascotaActual.getString("fotoBase64");

                                if (fotoBase64 != null && !fotoBase64.isEmpty()) {
                                    try {
                                        // 1. Quitar el tinte azul por defecto
                                        ivPerfilMascota.setImageTintList(null);

                                        // 2. Decodificar el texto a bytes
                                        byte[] decodedString = android.util.Base64.decode(fotoBase64, android.util.Base64.DEFAULT);

                                        // 3. Convertir los bytes a un mapa de bits (Bitmap)
                                        android.graphics.Bitmap decodedByte = android.graphics.BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                                        // 4. Mostrarlo en pantalla
                                        ivPerfilMascota.setImageBitmap(decodedByte);
                                        ivPerfilMascota.setScaleType(ImageView.ScaleType.CENTER_CROP);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    // Si no tiene foto guardada, le ponemos el ícono por defecto
                                    ivPerfilMascota.setImageResource(android.R.drawable.ic_menu_myplaces);
                                }

                                String mascotaId = mascotaActual.getId(); // Sacamos el ID secreto de Firebase

                                ivOpcionesMascota.setOnClickListener(v -> {
                                    Intent intent = new Intent(dashboard.this, editar_mascota.class);
                                    intent.putExtra("MASCOTA_ID", mascotaId); // Se lo mandamos a la otra pantalla
                                    startActivity(intent);
                                });
                                // =======================================================

                            } else {
                                // Si está vacío, mostramos el botón de agregar
                                layoutSinMascotas.setVisibility(View.VISIBLE);
                                layoutConMascotas.setVisibility(View.GONE);
                            }

                        }
                    });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 1. Leemos la memoria para ver qué mascota está seleccionada actualmente
        android.content.SharedPreferences prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);

        // 1. Revisar si cambió de mascota activa
        String idSeleccionado = prefs.getString("mascotaActivaId", null);
        if (idMascotaPintada != null && idSeleccionado != null && !idMascotaPintada.equals(idSeleccionado)) {
            idMascotaPintada = idSeleccionado;
            recreate();
            return; // Detenemos aquí para que recargue tranquilo
        }

        // 2. Si no cambió de mascota, actualizamos SOLO el texto del peso al instante
        if (tvDashboardPeso != null && pesoOriginalMascota != null && !pesoOriginalMascota.isEmpty()) {
            boolean usarLibras = prefs.getBoolean("usarLibras", false);
            try {
                double pesoOriginalKg = Double.parseDouble(pesoOriginalMascota);
                if (usarLibras) {
                    double pesoLb = pesoOriginalKg * 2.20462;
                    tvDashboardPeso.setText(String.format("Peso: %.2f Lb", pesoLb));
                } else {
                    tvDashboardPeso.setText("Peso: " + pesoOriginalMascota + " Kg");
                }
            } catch (Exception e) {
                tvDashboardPeso.setText("Peso: " + pesoOriginalMascota);
            }
        }
    }
}