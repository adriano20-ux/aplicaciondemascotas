package com.example.aplicacionparamascotas;

public class Mascota {
    private String id;
    private String nombre;
    private String especie;
    private String raza;
    private String fechaNacimiento;
    private String peso;

    // Constructor vacío requerido por Firebase
    public Mascota() {}

    public Mascota(String id, String nombre, String especie, String raza, String fechaNacimiento, String peso) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.fechaNacimiento = fechaNacimiento;
        this.peso = peso;
    }

    // Getters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEspecie() { return especie; }
    public String getRaza() { return raza; }
    public String getFechaNacimiento() { return fechaNacimiento; }
    public String getPeso() { return peso; }

    // Setters
    public void setId(String id) { this.id = id; }
}
