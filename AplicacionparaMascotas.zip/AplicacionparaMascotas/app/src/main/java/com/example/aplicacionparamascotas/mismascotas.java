package com.example.aplicacionparamascotas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class mismascotas extends AppCompatActivity {

    private ImageView ivVolverDashboard;
    private RecyclerView rvMascotas;
    private FloatingActionButton fabAgregarMascota;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private MascotaAdapter adapter;
    private List<Mascota> listaMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mismascotas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        ivVolverDashboard = findViewById(R.id.ivVolverDashboard);
        rvMascotas = findViewById(R.id.rvMascotas);
        fabAgregarMascota = findViewById(R.id.fabAgregarMascota);

        // Configurar la lista
        rvMascotas.setLayoutManager(new LinearLayoutManager(this));
        listaMascotas = new ArrayList<>();
        adapter = new MascotaAdapter(listaMascotas);
        rvMascotas.setAdapter(adapter);

        ivVolverDashboard.setOnClickListener(v -> finish());

        // Botón flotante para ir a agregar otra mascota
        fabAgregarMascota.setOnClickListener(v -> {
            startActivity(new Intent(mismascotas.this, agregar_mascota.class));
        });

        cargarMascotas();
    }

    private void cargarMascotas() {
        String userId = mAuth.getCurrentUser().getUid();

        db.collection("Usuarios").document(userId).collection("MisMascotas")
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Toast.makeText(this, "Error al cargar", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    listaMascotas.clear();
                    if (value != null) {
                        for (DocumentSnapshot doc : value.getDocuments()) {
                            Mascota m = doc.toObject(Mascota.class);
                            if (m != null) {
                                m.setId(doc.getId()); // Guardamos el ID de Firebase
                                listaMascotas.add(m);
                            }
                        }
                        adapter.notifyDataSetChanged(); // Refrescar la lista visualmente
                    }
                });
    }

    // ======================================================================
    // ADAPTADOR INTERNO: Se encarga de clonar los item_mascota.xml
    // ======================================================================
    class MascotaAdapter extends RecyclerView.Adapter<MascotaAdapter.MascotaViewHolder> {

        private List<Mascota> mascotas;
        private String mascotaActivaId; // Para saber cuál tiene el check verde

        public MascotaAdapter(List<Mascota> mascotas) {
            this.mascotas = mascotas;
            // Leer de memoria cuál es la mascota activa actual
            SharedPreferences prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
            mascotaActivaId = prefs.getString("mascotaActivaId", "");
        }

        @NonNull
        @Override
        public MascotaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mascota, parent, false);
            return new MascotaViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MascotaViewHolder holder, int position) {
            Mascota mascota = mascotas.get(position);
            holder.tvItemNombreMascota.setText(mascota.getNombre());
            holder.tvItemRaza.setText(mascota.getRaza());

            // Mostrar el check verde si es la mascota seleccionada
            if (mascota.getId().equals(mascotaActivaId)) {
                holder.ivMascotaSeleccionada.setVisibility(View.VISIBLE);
            } else {
                holder.ivMascotaSeleccionada.setVisibility(View.GONE);
            }

            // Cambiar mascota activa al hacer clic en la tarjeta
            holder.itemView.setOnClickListener(v -> {
                SharedPreferences prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
                prefs.edit().putString("mascotaActivaId", mascota.getId()).apply();

                mascotaActivaId = mascota.getId();
                notifyDataSetChanged(); // Recargar los checks
                Toast.makeText(mismascotas.this, mascota.getNombre() + " seleccionado", Toast.LENGTH_SHORT).show();
                finish(); // Regresar al Dashboard
            });
        }

        @Override
        public int getItemCount() {
            return mascotas.size();
        }

        class MascotaViewHolder extends RecyclerView.ViewHolder {
            TextView tvItemNombreMascota, tvItemRaza;
            ImageView ivMascotaSeleccionada;

            public MascotaViewHolder(@NonNull View itemView) {
                super(itemView);
                tvItemNombreMascota = itemView.findViewById(R.id.tvItemNombreMascota);
                tvItemRaza = itemView.findViewById(R.id.tvItemRaza);
                ivMascotaSeleccionada = itemView.findViewById(R.id.ivMascotaSeleccionada);
            }
        }
    }
}