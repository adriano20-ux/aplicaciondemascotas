package com.example.aplicacionparamascotas;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class RecordatorioReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // 1. REVISAMOS LOS AJUSTES ANTES DE HACER CUALQUIER COSA
        SharedPreferences prefs = context.getSharedPreferences("AjustesApp", Context.MODE_PRIVATE);
        boolean notificacionesActivas = prefs.getBoolean("notificaciones_activas", true);

        // Si el usuario las apagó en los Ajustes, abortamos la misión y no hacemos nada
        if (!notificacionesActivas) {
            return;
        }

        // 2. SI ESTÁN ACTIVAS, LANZAMOS LA NOTIFICACIÓN
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String canalId = "canal_agenda";

        // Android moderno exige crear un "Canal" de notificaciones
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(canalId, "Agenda de Mascotas", NotificationManager.IMPORTANCE_HIGH);
            manager.createNotificationChannel(canal);
        }

        // Armamos la notificación visual
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, canalId)
                .setSmallIcon(android.R.drawable.ic_dialog_info) // Ícono por defecto
                .setContentTitle("¡Recordatorio de tu Mascota!")
                .setContentText("Tienes una tarea pendiente en tu agenda.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        manager.notify(1, builder.build());
    }
}

