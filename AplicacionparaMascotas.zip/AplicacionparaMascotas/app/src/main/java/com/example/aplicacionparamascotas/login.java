package com.example.aplicacionparamascotas;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class login extends AppCompatActivity {
    private FirebaseAuth mAuth;

    private TextInputEditText etLoginCorreo, etLoginPassword;
    private Button btnIniciarSesion;
    private TextView tvOlvidoPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
        etLoginCorreo = findViewById(R.id.etLoginCorreo);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        btnIniciarSesion = findViewById(R.id.btnIniciarSesion);
        tvOlvidoPassword = findViewById(R.id.tvOlvidoPassword);

        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarLogin();
            }
        });

        tvOlvidoPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtenemos el correo que el usuario haya escrito en el campo
                String correo = etLoginCorreo.getText().toString().trim();

                // Validamos que haya escrito algo y que tenga formato de correo válido
                if (correo.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                    etLoginCorreo.setError("Para recuperar tu contraseña, primero escribe tu correo aquí");
                    etLoginCorreo.requestFocus();
                    return;
                }

                Toast.makeText(login.this, "Enviando enlace de recuperación...", Toast.LENGTH_SHORT).show();

                // Pedimos a Firebase que envíe el correo de reseteo
                mAuth.sendPasswordResetEmail(correo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {

                                    Toast.makeText(login.this, "¡Correo enviado! Revisa tu bandeja de entrada (o la carpeta de Spam).", Toast.LENGTH_LONG).show();
                                } else {

                                    Toast.makeText(login.this, "Error al enviar: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });

        TextView tvVolver = findViewById(R.id.tvVolver);
        tvVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
    }

    private void validarLogin() {
        String correo = etLoginCorreo.getText().toString().trim();
        String password = etLoginPassword.getText().toString().trim();

        // Validaciones básicas de que los campos no estén vacíos
        if (correo.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            etLoginCorreo.setError("Ingresa un correo electrónico válido");
            etLoginCorreo.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etLoginPassword.setError("La contraseña es requerida");
            etLoginPassword.requestFocus();
            return;
        }

        Toast.makeText(this, "Verificando credenciales...", Toast.LENGTH_SHORT).show();

        // Aquí ocurre la magia: Firebase verifica si el correo y clave coinciden
        mAuth.signInWithEmailAndPassword(correo, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // ¡Éxito! Las credenciales son correctas
                            Toast.makeText(login.this, "¡Bienvenido!", Toast.LENGTH_SHORT).show();

                            // Redirigir al Dashboard
                            Intent intent = new Intent(login.this, dashboard.class);

                            // Esto limpia el historial para que si le da "Atrás", no vuelva al login sino que salga de la app
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);

                            finish(); // Cierra la pantalla de login
                        } else {
                            // Error: Contraseña incorrecta, correo no existe, o no hay internet
                            Toast.makeText(login.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}