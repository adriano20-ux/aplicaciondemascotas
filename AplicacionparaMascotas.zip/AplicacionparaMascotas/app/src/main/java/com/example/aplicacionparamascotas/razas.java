package com.example.aplicacionparamascotas;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.widget.ArrayAdapter;

import android.widget.ListView;


import com.bumptech.glide.Glide;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class razas extends AppCompatActivity {

    private RecyclerView recyclerRazas;
    private SearchView searchBuscador;
    private ArrayList<Raza> listaRazasDatos;
    private RazaAdapter adapter;
    private FirebaseFirestore db;

    // 1. Modelo con tus nuevas ideas
    class Raza {
        String nombre, descripcion, tiempoVida, idealPara, peso, altura, imagenUrl;

        public Raza(String nombre, String descripcion, String tiempoVida, String idealPara, String peso, String altura, String imagenUrl) {
            this.nombre = nombre; this.descripcion = descripcion;
            this.tiempoVida = tiempoVida; this.idealPara = idealPara;
            this.peso = peso; this.altura = altura; this.imagenUrl = imagenUrl;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_razas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        db = FirebaseFirestore.getInstance();

        ImageView ivVolverRazas = findViewById(R.id.ivVolverRazas);
        ivVolverRazas.setOnClickListener(v -> finish());

        searchBuscador = findViewById(R.id.searchBuscador);
        recyclerRazas = findViewById(R.id.recyclerRazas);

        // AQUÍ CONFIGURAMOS LA CUADRÍCULA DE 2 COLUMNAS
        recyclerRazas.setLayoutManager(new GridLayoutManager(this, 2));

        listaRazasDatos = new ArrayList<>();
        adapter = new RazaAdapter(listaRazasDatos);
        recyclerRazas.setAdapter(adapter);

        cargarRazasDesdeFirebase();

        // Buscador simplificado
        searchBuscador.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) { return false; }

            @Override
            public boolean onQueryTextChange(String newText) {
                filtrar(newText);
                return true;
            }
        });
    }

    private void cargarRazasDesdeFirebase() {
        db.collection("Razas").orderBy("nombre").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                listaRazasDatos.clear();
                for (QueryDocumentSnapshot doc : task.getResult()) {
                    listaRazasDatos.add(new Raza(
                            doc.getString("nombre"), doc.getString("descripcion"),
                            doc.getString("tiempo_vida"), doc.getString("ideal_para"),
                            doc.getString("peso"), doc.getString("altura"),
                            doc.getString("imagen_url")
                    ));
                }
                adapter.actualizarLista(listaRazasDatos);
            } else {
                Toast.makeText(razas.this, "Error al cargar datos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filtrar(String texto) {
        ArrayList<Raza> filtrada = new ArrayList<>();
        for (Raza raza : listaRazasDatos) {
            if (raza.nombre.toLowerCase().contains(texto.toLowerCase())) {
                filtrada.add(raza);
            }
        }
        adapter.actualizarLista(filtrada);
    }

    class RazaAdapter extends RecyclerView.Adapter<RazaAdapter.ViewHolder> {
        private ArrayList<Raza> listaLocal;

        public RazaAdapter(ArrayList<Raza> lista) { this.listaLocal = lista; }

        public void actualizarLista(ArrayList<Raza> nuevaLista) {
            this.listaLocal = nuevaLista;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_raza, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Raza raza = listaLocal.get(position);
            holder.tvNombre.setText(raza.nombre);

            // Cargamos la imagen con la librería Glide
            if (raza.imagenUrl != null && !raza.imagenUrl.isEmpty()) {
                Glide.with(holder.itemView.getContext())
                        .load(raza.imagenUrl)
                        .override(300, 300)
                        .centerCrop()
                        .into(holder.ivFoto);
            }

            // Al hacer clic en la tarjeta
            holder.itemView.setOnClickListener(v -> {
                String info = (raza.descripcion != null ? raza.descripcion : "Sin descripción.") + "\n\n" +
                        "⚖️ Peso: " + (raza.peso != null ? raza.peso : "--") + "\n" +
                        "📏 Altura: " + (raza.altura != null ? raza.altura : "--") + "\n" +
                        "⏳ Vida: " + (raza.tiempoVida != null ? raza.tiempoVida : "--") + "\n" +
                        "✨ Ideal: " + (raza.idealPara != null ? raza.idealPara : "--");

                new AlertDialog.Builder(razas.this)
                        .setTitle(raza.nombre)
                        .setMessage(info)
                        .setPositiveButton("Cerrar", null)
                        .show();
            });
        }

        @Override
        public int getItemCount() { return listaLocal.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNombre; ImageView ivFoto;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvNombre = itemView.findViewById(R.id.tvNombreRaza);
                ivFoto = itemView.findViewById(R.id.ivFotoRaza);
            }
        }
    }
}